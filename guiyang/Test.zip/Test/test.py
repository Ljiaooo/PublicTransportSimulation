import traci





traci.start(['sumo-gui','-c','guiyang.sumocfg'])


#add a person at 47_0(the first stop in stop_47.add.xml)
#append waiting stage for 10s
traci.person.add("testPerson",edgeID='593486825#3',pos=150.0)
traci.person.appendWaitingStage("testPerson",duration=10)


#print(traci.busstop.getPersonCount('47_0'))

step = 0
while step < 1000:
    traci.simulation.step()
    if step == 5:
        #print the person count at stop_47 
        #the print result is 0 (where is the problem?)
        print(traci.busstop.getPersonCount('47_0'))
    if step == 6:
        #test driving stage
        traci.person.removeStages("testPerson")
        traci.person.appendDrivingStage("testPerson",toEdge='593486825#3', lines='47')
    
    if step == 7:
        #the print result is also 0, but the person is actually waiting at stop_47 for bus 
        print(traci.busstop.getPersonCount('47_0'))
    


    step += 1


